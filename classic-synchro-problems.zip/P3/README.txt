Implementation:

1 - Bounded Buffer Problem

In the C++ code above, we have used semaphores to create a bounded buffer solution. We have also used multithreading to create three producer threads and three consumer threads. The program is composed of a producer function, which deposits a number of items into a circular buffer (numIters), and a consumer function, which gathers and sums up the items from the circular buffer. In the main function, we use semaphores for synchronization. Semaphores control how many empty and full slots are in the buffer. We also use sem_mutex to avoid race conditions during critical sections. The program accepts command-line arguments (Number of iterations, Buffer Size) and performs input validation. It also dynamically allocates the memory for the buffer.

2 - One-Lane Bridge Problem

This C++ code presents a simulation of cars crossing a bridge using multithreading and synchronization mechanisms. The code includes a Bridge class that represents the bridge and contains methods for cars to arrive at the bridge, cross it, and exit from it. To ensure thread-safe access and control the flow of cars on the bridge, the Bridge class utilizes a mutex and a condition variable. The OneCar function represents each car and randomly selects a direction of travel before simulating the car's journey across the bridge by calling the appropriate Bridge methods. The main function creates 50 threads, each representing a car, and concurrently simulates their behavior of arriving, crossing, and exiting the bridge. To enhance the realism of the simulation, random delays between car arrivals are introduced. In summary, this program serves as an example of implementing a concurrency and mutual exclusion problem with a significant number of threads.

3 - Savings Account Problem (a)

In this C++ program, we have developed a basic banking system solution by incorporating multithreading and synchronization techniques. The code introduces a Bank class that includes functions for depositing, withdrawing, and checking the account balance. To ensure that only one thread accesses the balance at a time, the Bank class utilizes a mutex for mutual exclusion. Moreover, it utilizes a condition variable (okToWithdraw) to indicate when it is permissible to withdraw money based on the current balance. The main function spawns six threads, each representing a transaction (deposit or withdrawal) on the bank account. These threads execute operations concurrently, and the program provides feedback messages indicating the success or failure of withdrawals and deposits. Finally, the program presents the final account balance after all transactions have been processed, demonstrating the application of multithreading and synchronization in a banking scenario to manage simultaneous access to shared resources.

4 - Savings Account Problem (b)

We have developed a simulation of a First-Come-First-Served (FCFS) banking system using multithreading and synchronization mechanisms in this C++ code. The FCFSBank class is responsible for representing a bank and includes methods for depositing, withdrawing, and checking the account balance. To ensure proper order of withdrawal requests, the class utilizes two condition variables (okToWithdraw and okToBank) and a mutex for mutual exclusion. When a withdrawal request is made, the thread waits until it is its turn to withdraw, based on the order of requests and the availability of sufficient funds in the account. The program includes various example scenarios that demonstrate different behaviors of the FCFSBank class, such as normal deposit and withdrawal operations, withdrawals following the FCFS order, deposits not waiting for withdrawals, withdrawals waiting for a sufficient balance, and multiple withdrawals waiting for funds in their respective turns. Upon completion of all transactions, the program outputs the final balance of the account, showcasing the implementation of FCFS using multithreading and synchronization in a banking system scenario.

_____________________________________________________________________________________________
How to run programs:

1 - Bounded Buffer Problem

Enter the <Number of iterations> <Buffer Size> and then run the program.

2 - One-Lane Bridge Problem

Simply hit run to run the program.

3 - Savings Account Problem (a)

Simply hit run to see the test case run.

4 - Savings Account Problem (b)

Uncomment one of the examples in main at a time and hit run to see the different test cases.

_____________________________________________________________________________________________
Savings Account Algorithms:

1 - Savings Account Problem (a)

Monitor Bank {
int balance = 0
cond okToWithdraw;
void Deposit(int amount) {
balance = balance + amount;
okToWithdraw->broadcast();
}
void Withdraw(int amount) {
//wait for funds
while (amount > balance) {
okToWithdraw->wait();
}
balance = balance – amount;
}
}

2 - Savings Account Problem (b)


Monitor FCFSBank {
int balance = 0;
int numOfWithdraw = 0;
cond okToWithdraw;
cond okToBank;
void Deposit(int amount) {
balance = balance + amount;
okToWithdraw->signal(); //it is also fine,
okToWithdraw->broadcast();
}
void Withdraw(int amount) {
numOfWithdraw++;
//Somebody is ahead, wait for turn
if (numOfWithdraw > 1) { //it cannot be a while
loop
okToBank->wait();
}
//wait for funds
while (amount > balance) {
okToWithdraw->wait();
}
balance = balance â amount;
numOfWithdraw--;
okToBank->signal(); // signal the next withdraw
}
}

_____________________________________________________________________________________________
Sample outputs:

1 - Bounded Buffer Problem

Example 1 (Input: 100 100):

the total is 4950
the total is 4950
the total is 4950

Example 2 (Input: 100 10):

the total is 4950
the total is 4950
the total is 4950

Example 3 (Input: 1000 10):

the total is 499500
the total is 499500
the total is 499500

2 - One-Lane Bridge Problem

Car 0 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 0 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 0 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 1 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 1 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 1 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 2 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 2 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 3 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 3 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 2 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 3 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 4 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 4 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 4 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 5 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 5 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 6 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 6 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 5 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 7 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 7 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 6 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 7 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 8 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 8 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 8 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 9 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 9 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 10 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 10 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 9 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 11 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 11 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 10 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 11 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 12 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 12 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 12 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 13 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 13 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 13 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 14 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 14 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 15 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 15 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 14 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 16 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 16 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 15 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 16 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 17 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 17 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 17 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 18 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 18 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 18 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 19 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 19 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 20 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 20 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 19 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 20 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 21 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 21 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 22 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 22 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 21 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 22 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 23 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 23 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 23 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 24 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 24 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 25 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 25 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 24 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 25 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 26 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 26 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 26 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 27 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 27 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 27 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 28 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 28 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 29 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 2.
Car 29 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 2.
Car 28 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 1.
Car 29 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 30 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 30 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 30 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 31 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 31 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 32 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 2.
Car 32 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 2.
Car 31 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 1.
Car 32 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 33 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 33 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 33 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 34 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 34 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 35 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 35 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 34 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 36 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 36 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 35 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 37 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 37 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 36 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 38 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 2.
Car 38 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 2.
Car 37 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 1.
Car 38 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 39 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 39 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 39 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 40 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 40 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 40 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 41 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 41 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 41 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 42 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 42 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 43 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 2.
Car 43 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 2.
Car 42 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 1.
Car 43 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 44 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 44 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 44 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 45 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 45 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 45 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 46 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 46 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 46 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 47 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 47 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 47 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.
Car 48 traveling in direction 0 has arrived at the bridge. CurrDir: 0. #Cars: 1.
Car 48 traveling in direction 0 is crossing the bridge. CurrDir: 0. #Cars: 1.
Car 48 traveling in direction 0 has exited from the bridge. CurrDir: 0. #Cars: 0.
Car 49 traveling in direction 1 has arrived at the bridge. CurrDir: 1. #Cars: 1.
Car 49 traveling in direction 1 is crossing the bridge. CurrDir: 1. #Cars: 1.
Car 49 traveling in direction 1 has exited from the bridge. CurrDir: 1. #Cars: 0.

3 - Savings Account Problem (a)

Deposited $2000, New Balance: $2000
Withdrew: $700, New Balance: $1300
Withdraw: $4000 FAILED. Insufficient bank balance or lower priority. Waiting for additional funds or your turn.
Deposited $5000, New Balance: $6300
Withdrew: $4000, New Balance: $2300
Withdraw: $4000 FAILED. Insufficient bank balance or lower priority. Waiting for additional funds or your turn.
Deposited $1000, New Balance: $3300
Withdraw: $4000 FAILED. Insufficient bank balance or lower priority. Waiting for additional funds or your turn.


4 - Savings Account Problem (b)

Example 1:

Deposited: $300, New Balance: $300
Withdrew: $100, New Balance: $200
Final Balance: $200

Example 2:

Withdraw: $100 FAILED. Insufficient bank balance or lower priority. Waiting for additional funds or your turn.
Deposited: $250, New Balance: $250
Withdrew: $100, New Balance: $150
Withdrew: $150, New Balance: $0
Final Balance: $0

Example 3:

Deposited: $100, New Balance: $100
Deposited: $100, New Balance: $200
Withdrew: $50, New Balance: $150
Final Balance: $150

Example 4:

Withdraw: $400 FAILED. Insufficient bank balance or lower priority. Waiting for additional funds or your turn.
Deposited: $500, New Balance: $500
Withdrew: $400, New Balance: $100
Final Balance: $100

Example 5:

Withdraw: $50 FAILED. Insufficient bank balance or lower priority. Waiting for additional funds or your turn.
Deposited: $100, New Balance: $100
Withdrew: $50, New Balance: $50
Deposited: $400, New Balance: $450

